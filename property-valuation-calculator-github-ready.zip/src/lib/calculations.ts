import { CalculationResult, CalcId } from "../types";
import { annuityPV, irr, pvFactor, sinkingFundFactor, ypPerpetuity, ypTerm, pct } from "./finance";

const n = (v: string) => {
  const x = Number(v);
  if (!Number.isFinite(x)) throw new Error("Enter valid numeric values.");
  return x;
};
const money = (v: number) => `₦${v.toLocaleString("en-NG", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
const f = (v: number, d = 6) => Number(v).toFixed(d).replace(/\.?0+$/, "");

export function calculate(id: CalcId, x: Record<string, string>): CalculationResult {
  switch (id) {
    case "yp-perpetuity": {
      const income=n(x.income), rate=n(x.rate), yp=ypPerpetuity(rate), value=income*yp;
      return {title:"Y.P. in Perpetuity", resultLabel:"Capital Value", result:value, formula:"Y.P. = 1 / r; Value = Income × Y.P.", working:[`Income = ${money(income)}`,`Yield = ${rate}%`,`Y.P. = 1 / ${rate/100} = ${f(yp)}`,`Value = ${money(income)} × ${f(yp)} = ${money(value)}`]};
    }
    case "yp-term": {
      const income=n(x.income), rate=n(x.rate), years=n(x.years), yp=ypTerm(rate,years), value=income*yp;
      return {title:"Y.P. for Term Certain",resultLabel:"Capital Value",result:value,formula:"Y.P. = [1 − (1+r)^−n] / r",working:[`Income = ${money(income)}`,`Yield = ${rate}%`, `Term = ${years} years`,`Y.P. = ${f(yp)}`,`Value = ${money(value)}`]};
    }
    case "present-value": {
      const future=n(x.future), rate=n(x.rate), years=n(x.years), factor=pvFactor(rate,years), value=future*factor;
      return {title:"Present Value",resultLabel:"Present Value",result:value,formula:"PV = FV / (1+r)^n",working:[`Future value = ${money(future)}`,`Rate = ${rate}%`, `Period = ${years} years`,`PV factor = ${f(factor)}`,`PV = ${money(future)} × ${f(factor)} = ${money(value)}`]};
    }
    case "annuity": {
      const payment=n(x.payment), rate=n(x.rate), years=n(x.years), yp=ypTerm(rate,years), value=payment*yp;
      return {title:"Annuity",resultLabel:"Present Value",result:value,formula:"PV = Payment × [1 − (1+r)^−n] / r",working:[`Payment = ${money(payment)}`,`Rate = ${rate}%`,`Term = ${years} years`,`Annuity factor = ${f(yp)}`,`PV = ${money(value)}`]};
    }
    case "deferred-annuity": {
      const payment=n(x.payment), rate=n(x.rate), years=n(x.years), defer=n(x.defer), yp=ypTerm(rate,years), factor=pvFactor(rate,defer), value=payment*yp*factor;
      return {title:"Deferred Annuity",resultLabel:"Present Value",result:value,formula:"Value = Payment × Y.P. × PV factor for deferral",working:[`Payment = ${money(payment)}`,`Rate = ${rate}%`,`Income term = ${years} years`,`Deferred period = ${defer} years`,`Y.P. = ${f(yp)}`,`Deferral PV factor = ${f(factor)}`,`Value = ${money(value)}`]};
    }
    case "sinking-fund": {
      const target=n(x.target), rate=n(x.rate), years=n(x.years), sf=sinkingFundFactor(rate,years), value=target*sf;
      return {title:"Sinking Fund",resultLabel:"Annual Contribution",result:value,formula:"SFF = r / [(1+r)^n − 1]; Contribution = Target × SFF",working:[`Target = ${money(target)}`,`Rate = ${rate}%`,`Term = ${years} years`,`Sinking-fund factor = ${f(sf)}`,`Annual contribution = ${money(value)}`]};
    }
    case "investment": {
      const gross=n(x.gross), out=n(x.outgoings), rate=n(x.rate), net=gross-out, value=net/pct(rate);
      if(rate<=0) throw new Error("Yield must be greater than zero.");
      return {title:"Investment Method",resultLabel:"Capital Value",result:value,formula:"Value = Net Income / Yield",working:[`Gross income = ${money(gross)}`,`Outgoings = ${money(out)}`,`Net income = ${money(net)}`,`Yield = ${rate}%`,`Value = ${money(net)} / ${rate/100} = ${money(value)}`]};
    }
    case "term-reversion": {
      const current=n(x.current), market=n(x.market), years=n(x.years), rate=n(x.rate), term=current*ypTerm(rate,years), rev=market*ypPerpetuity(rate)*pvFactor(rate,years), value=term+rev;
      return {title:"Term & Reversion",resultLabel:"Capital Value",result:value,formula:"Value = Term value + Reversion value",working:[`Current rent = ${money(current)}`,`Market rent = ${money(market)}`,`Term = ${years} years; Yield = ${rate}%`,`Term Y.P. = ${f(ypTerm(rate,years))}`,`Term value = ${money(term)}`,`Perpetuity Y.P. = ${f(ypPerpetuity(rate))}`,`PV factor to reversion = ${f(pvFactor(rate,years))}`,`Reversion value = ${money(rev)}`,`Total = ${money(value)}`]};
    }
    case "hardcore": {
      const a=n(x.income1), ar=n(x.rate1), b=n(x.income2), br=n(x.rate2), av=a/pct(ar), bv=b/pct(br), value=av+bv;
      return {title:"Hardcore / Layer Method",resultLabel:"Capital Value",result:value,formula:"Each income layer is capitalised at its applicable yield.",working:[`Layer 1 = ${money(a)} / ${ar}% = ${money(av)}`,`Layer 2 = ${money(b)} / ${br}% = ${money(bv)}`,`Total value = ${money(value)}`]};
    }
    case "leasehold": {
      const income=n(x.income), years=n(x.years), rate=n(x.rate), yp=ypTerm(rate,years), value=income*yp;
      return {title:"Leasehold Valuation",resultLabel:"Leasehold Value",result:value,formula:"Value = Net Income × Y.P. of unexpired term",working:[`Net income = ${money(income)}`,`Unexpired term = ${years} years`,`Yield = ${rate}%`,`Y.P. = ${f(yp)}`,`Leasehold value = ${money(value)}`]};
    }
    case "comparison": {
      const price=n(x.price), area=n(x.area), adj=n(x.adjustment||"0"), subject=n(x.subjectArea), rate=price/area, adjusted=rate*(1+pct(adj)), value=adjusted*subject;
      return {title:"Comparison Method",resultLabel:"Estimated Value",result:value,formula:"Rate = Sale Price / Area; Adjusted Rate × Subject Area",working:[`Comparable sale = ${money(price)}`,`Comparable area = ${area} m²`,`Base rate = ${money(rate)} / m²`,`Adjustment = ${adj}%`,`Adjusted rate = ${money(adjusted)} / m²`,`Subject area = ${subject} m²`,`Estimated value = ${money(value)}`]};
    }
    case "cost": {
      const land=n(x.land), cost=n(x.cost), dep=n(x.dep), building=cost*(1-pct(dep)), value=land+building;
      return {title:"Cost Method",resultLabel:"Property Value",result:value,formula:"Value = Land Value + Depreciated Building Value",working:[`Land value = ${money(land)}`,`Building replacement cost = ${money(cost)}`,`Depreciation = ${dep}%`, `Depreciated building = ${money(building)}`,`Property value = ${money(value)}`]};
    }
    case "depreciation": {
      const cost=n(x.cost), salvage=n(x.salvage), life=n(x.life), age=n(x.age), annual=(cost-salvage)/life, dep=Math.min(age,life)*annual, value=Math.max(salvage,cost-dep);
      return {title:"Straight-Line Depreciation",resultLabel:"Depreciated Value",result:value,formula:"Annual depreciation = (Cost − Salvage) / Life",working:[`Cost = ${money(cost)}`,`Salvage = ${money(salvage)}`,`Useful life = ${life} years`,`Annual depreciation = ${money(annual)}`,`Age = ${age} years`,`Accumulated depreciation = ${money(dep)}`,`Depreciated value = ${money(value)}`]};
    }
    case "residual": {
      const gdv=n(x.gdv), costs=["land","construction","professional","finance","marketing","contingency","other"].reduce((s,k)=>s+n(x[k]||"0"),0), profitMode=x.profitMode||"fixed", profit=profitMode==="percent"?costs*pct(n(x.profit)):n(x.profit), value=gdv-costs-profit;
      return {title:"Residual Method",resultLabel:"Residual Land Value",result:value,formula:"Residual = GDV − Development Costs − Developer's Profit",working:[`GDV = ${money(gdv)}`,`Total development costs = ${money(costs)}`,`Developer's profit = ${money(profit)}`,`Residual land value = ${money(value)}`]};
    }
    case "development": {
      const sales=n(x.sales), costs=["land","construction","professional","finance","marketing","contingency","other"].reduce((s,k)=>s+n(x[k]||"0"),0), profit=sales-costs, profitPct=costs?profit/costs*100:0;
      return {title:"Development Appraisal",resultLabel:"Development Profit",result:profit,formula:"Profit = GDV − Total Development Cost",working:[`GDV / expected sales = ${money(sales)}`,`Total development cost = ${money(costs)}`,`Development profit = ${money(profit)}`,`Profit on cost = ${profitPct.toFixed(2)}%`]};
    }
    case "dcf":
    case "npv": {
      const initial=n(x.initial), rate=n(x.rate), flows=(x.flows||"").split(",").map(Number).filter(v=>Number.isFinite(v));
      if(!flows.length) throw new Error("Enter cash flows separated by commas.");
      const rows=flows.map((cf,i)=>({year:i+1,cf,pv:cf*pvFactor(rate,i+1)})), total=rows.reduce((s,r)=>s+r.pv,0), value=id==="npv"?total-initial:total;
      return {title:id==="dcf"?"Discounted Cash Flow":"Net Present Value",result:value,resultLabel:id==="dcf"?"Total Present Value":"NPV",formula:id==="dcf"?"PV = CF / (1+r)^n":"NPV = Σ[CF/(1+r)^n] − Initial Investment",working:[`Initial investment = ${money(initial)}`,`Discount rate = ${rate}%`,...rows.map(r=>`Year ${r.year}: ${money(r.cf)} → PV ${money(r.pv)}`),`${id==="dcf"?"Total PV":"NPV"} = ${money(value)}`]};
    }
    case "irr": {
      const flows=(x.flows||"").split(",").map(Number).filter(v=>Number.isFinite(v)), rate=irr(flows), value=rate*100;
      return {title:"Internal Rate of Return",result:value,resultLabel:"IRR",formula:"IRR is the rate at which NPV = 0.",working:[`Cash flows = ${flows.map(money).join(", ")}`,`Calculated IRR = ${value.toFixed(6)}%`,`At this rate, NPV is approximately zero.`]};
    }
    case "profit": {
      const receipts=n(x.receipts), expenses=n(x.expenses), share=n(x.share), div=Math.max(0,receipts-expenses-share), rate=n(x.rate), value=div/pct(rate);
      return {title:"Profit Method",resultLabel:"Capitalised Value",result:value,formula:"Divisible Balance = Gross Receipts − Working Expenses − Relevant Share",working:[`Gross receipts = ${money(receipts)}`,`Working expenses = ${money(expenses)}`,`Relevant share = ${money(share)}`,`Divisible balance = ${money(div)}`,`Yield = ${rate}%`,`Capitalised value = ${money(value)}`]};
    }
    case "yield": {
      const income=n(x.income), value=n(x.value), rate=income/value*100;
      return {title:"Yield / Capitalisation Rate",resultLabel:"Yield",result:rate,formula:"Yield = Net Income / Capital Value × 100",working:[`Net income = ${money(income)}`,`Capital value = ${money(value)}`,`Yield = ${money(income)} / ${money(value)} × 100 = ${rate.toFixed(4)}%`]};
    }
    case "ltv": {
      const value=n(x.value), loan=n(x.loan), ltv=loan/value*100, equity=value-loan;
      return {title:"Loan-to-Value",resultLabel:"LTV",result:ltv,formula:"LTV = Loan / Property Value × 100",working:[`Property value = ${money(value)}`,`Loan = ${money(loan)}`,`LTV = ${ltv.toFixed(4)}%`,`Equity = ${money(equity)}`]};
    }
    case "marriage": {
      const a=n(x.a), b=n(x.b), combined=n(x.combined), value=combined-a-b;
      return {title:"Marriage Value",resultLabel:"Marriage Value",result:value,formula:"Marriage Value = Combined Value − (A + B)",working:[`Interest A = ${money(a)}`,`Interest B = ${money(b)}`,`Combined value = ${money(combined)}`,`Marriage value = ${money(value)}`]};
    }
    case "compensation": {
      const keys=["land","disturbance","severance","injurious","other"], value=keys.reduce((s,k)=>s+n(x[k]||"0"),0);
      return {title:"Compensation",resultLabel:"Total Compensation",result:value,formula:"Total = Land/Interest Value + Disturbance + Severance + Injurious Affection + Other",working:keys.map(k=>`${k} = ${money(n(x[k]||"0"))}`).concat(`Total compensation = ${money(value)}`),notes:["Educational estimate only. Actual statutory compensation depends on applicable Nigerian law, facts, valuation date and professional/legal advice."]};
    }
  }
}