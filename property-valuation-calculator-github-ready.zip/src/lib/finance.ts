export const pct = (v: number) => v / 100;

export function ypPerpetuity(ratePct: number) {
  if (ratePct <= 0) throw new Error("Yield must be greater than zero.");
  return 1 / pct(ratePct);
}

export function ypTerm(ratePct: number, years: number) {
  if (ratePct <= 0) throw new Error("Yield must be greater than zero.");
  if (years <= 0) throw new Error("Term must be greater than zero.");
  const r = pct(ratePct);
  return (1 - Math.pow(1 + r, -years)) / r;
}

export function pvFactor(ratePct: number, years: number) {
  if (ratePct <= -100) throw new Error("Discount rate must be greater than -100%.");
  if (years < 0) throw new Error("Years cannot be negative.");
  return 1 / Math.pow(1 + pct(ratePct), years);
}

export function annuityPV(payment: number, ratePct: number, years: number) {
  return payment * ypTerm(ratePct, years);
}

export function sinkingFundFactor(ratePct: number, years: number) {
  if (ratePct <= 0) throw new Error("Sinking-fund rate must be greater than zero.");
  if (years <= 0) throw new Error("Term must be greater than zero.");
  const r = pct(ratePct);
  return r / (Math.pow(1 + r, years) - 1);
}

export function irr(cashFlows: number[], low = -0.99, high = 10) {
  if (cashFlows.length < 2) throw new Error("Enter at least two cash flows.");
  const npvAt = (rate: number) => cashFlows.reduce((sum, cf, i) => sum + cf / Math.pow(1 + rate, i), 0);
  let a = low, b = high, fa = npvAt(a), fb = npvAt(b);
  if (fa * fb > 0) {
    let previousR = -0.99, previousN = npvAt(previousR);
    for (let i = 1; i <= 1000; i++) {
      const r = -0.99 + (11 * i / 1000);
      const n = npvAt(r);
      if (previousN * n <= 0) { a = previousR; b = r; fa = previousN; fb = n; break; }
      previousR = r; previousN = n;
    }
  }
  if (fa * fb > 0) throw new Error("IRR could not be bracketed. Check the cash flows.");
  for (let i = 0; i < 200; i++) {
    const m = (a + b) / 2;
    const fm = npvAt(m);
    if (Math.abs(fm) < 1e-8) return m;
    if (fa * fm <= 0) { b = m; fb = fm; } else { a = m; fa = fm; }
  }
  return (a + b) / 2;
}