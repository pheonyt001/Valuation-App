import { describe, expect, it } from "vitest";
import { ypPerpetuity, ypTerm, pvFactor, sinkingFundFactor } from "./finance";

describe("valuation finance functions", () => {
  it("calculates perpetuity YP", () => expect(ypPerpetuity(10)).toBeCloseTo(10));
  it("calculates 10-year YP at 10%", () => expect(ypTerm(10,10)).toBeCloseTo(6.14457,4));
  it("calculates PV factor", () => expect(pvFactor(10,5)).toBeCloseTo(0.620921,5));
  it("calculates sinking fund factor", () => expect(sinkingFundFactor(8,10)).toBeCloseTo(0.06903,4));
});