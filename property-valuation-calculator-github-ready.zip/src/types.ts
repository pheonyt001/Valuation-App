export type CalcId =
  | "yp-perpetuity" | "yp-term" | "present-value" | "annuity" | "deferred-annuity"
  | "sinking-fund" | "investment" | "term-reversion" | "hardcore" | "leasehold"
  | "comparison" | "cost" | "depreciation" | "residual" | "development"
  | "dcf" | "npv" | "irr" | "profit" | "yield" | "ltv" | "marriage" | "compensation";

export type Field = {
  key: string;
  label: string;
  type?: "number" | "text";
  unit?: string;
  min?: number;
  step?: string;
  placeholder?: string;
};

export type CalculationResult = {
  title: string;
  resultLabel: string;
  result: number;
  formula: string;
  working: string[];
  notes?: string[];
};

export type HistoryItem = CalculationResult & {
  id: string;
  calculator: CalcId;
  createdAt: string;
  inputs: Record<string, string>;
};