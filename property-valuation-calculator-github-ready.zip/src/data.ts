import { CalcId, Field } from "./types";

export type Calculator = { id: CalcId; name: string; description: string; category: string; fields: Field[] };

const money = (key:string,label:string):Field => ({key,label,type:"number",unit:"₦",min:0,step:"0.01"});
const rate = (key:string="rate"):Field => ({key,label:"Yield / Rate",type:"number",unit:"%",min:-99.99,step:"0.01"});
const years = (key:string="years"):Field => ({key,label:"Number of Years",type:"number",min:0,step:"0.01"});

export const calculators: Calculator[] = [
{id:"yp-perpetuity",name:"Y.P. — Perpetuity",description:"Capitalise an income stream that continues indefinitely.",category:"Core Valuation",fields:[money("income","Annual Income"),rate()]},
{id:"yp-term",name:"Y.P. — Term Certain",description:"Calculate years' purchase for a fixed term.",category:"Core Valuation",fields:[money("income","Annual Income"),rate(),years()]},
{id:"present-value",name:"Present Value",description:"Bring a future amount back to present value.",category:"Core Valuation",fields:[money("future","Future Amount"),rate(),years()]},
{id:"annuity",name:"Annuity",description:"Present value of equal periodic payments.",category:"Core Valuation",fields:[money("payment","Annual Payment"),rate(),years()]},
{id:"deferred-annuity",name:"Deferred Annuity",description:"Value an annuity that starts after a deferral period.",category:"Core Valuation",fields:[money("payment","Annual Payment"),rate(),years(),years("defer")]},
{id:"sinking-fund",name:"Sinking Fund",description:"Calculate the annual contribution needed to reach a target.",category:"Core Valuation",fields:[money("target","Required Future Amount"),{...rate(),key:"rate",label:"Sinking Fund Rate"},years()]},
{id:"investment",name:"Investment Method",description:"Value income-producing property by capitalisation.",category:"Income Valuation",fields:[money("gross","Gross Annual Income"),money("outgoings","Annual Outgoings"),rate()]},
{id:"term-reversion",name:"Term & Reversion",description:"Value current income during the term plus the future reversion.",category:"Income Valuation",fields:[money("current","Current Rent"),money("market","Market Rent"),years(),rate()]},
{id:"hardcore",name:"Hardcore / Layer",description:"Capitalise different income layers at different yields.",category:"Income Valuation",fields:[money("income1","Layer 1 Income"),rate("rate1"),money("income2","Layer 2 Income"),rate("rate2")]},
{id:"leasehold",name:"Leasehold Valuation",description:"Value a leasehold interest over its unexpired term.",category:"Income Valuation",fields:[money("income","Net Annual Income"),years(),rate()]},
{id:"comparison",name:"Comparison Method",description:"Estimate value from a comparable sale and unit rate.",category:"Market Valuation",fields:[money("price","Comparable Sale Price"),{key:"area",label:"Comparable Area",type:"number",unit:"m²",min:0.01,step:"0.01"},{key:"adjustment",label:"Adjustment",type:"number",unit:"%",step:"0.01"},{key:"subjectArea",label:"Subject Area",type:"number",unit:"m²",min:0.01,step:"0.01"}]},
{id:"cost",name:"Cost Method",description:"Land value plus depreciated building value.",category:"Cost Valuation",fields:[money("land","Land Value"),money("cost","Building Replacement Cost"),{key:"dep",label:"Depreciation",type:"number",unit:"%",min:0,max:100,step:"0.01"}]},
{id:"depreciation",name:"Depreciation",description:"Straight-line depreciation and depreciated value.",category:"Cost Valuation",fields:[money("cost","Original Cost"),money("salvage","Salvage Value"),years("life"),years("age")]},
{id:"residual",name:"Residual Method",description:"Estimate residual land value from GDV and development costs.",category:"Development",fields:[money("gdv","Gross Development Value"),money("land","Land Acquisition Cost"),money("construction","Construction Cost"),money("professional","Professional Fees"),money("finance","Finance Cost"),money("marketing","Marketing Cost"),money("contingency","Contingency"),money("other","Other Costs"),{key:"profitMode",label:"Profit Mode",type:"text",placeholder:"fixed or percent"},{...money("profit","Developer Profit / %"),key:"profit"}]},
{id:"development",name:"Development Appraisal",description:"Summarise GDV, development costs and development profit.",category:"Development",fields:[money("sales","Expected Sales / GDV"),money("land","Land Cost"),money("construction","Construction Cost"),money("professional","Professional Fees"),money("finance","Finance Cost"),money("marketing","Marketing Cost"),money("contingency","Contingency"),money("other","Other Costs")]},
{id:"dcf",name:"Discounted Cash Flow",description:"Discount a sequence of future cash flows.",category:"Investment Analysis",fields:[money("initial","Initial Investment"),rate(),{key:"flows",label:"Future Cash Flows",type:"text",placeholder:"1000000,1200000,1500000"}]},
{id:"npv",name:"Net Present Value",description:"Calculate NPV from an initial investment and future cash flows.",category:"Investment Analysis",fields:[money("initial","Initial Investment"),rate(),{key:"flows",label:"Future Cash Flows",type:"text",placeholder:"1000000,1200000,1500000"}]},
{id:"irr",name:"Internal Rate of Return",description:"Calculate IRR from a sequence of cash flows.",category:"Investment Analysis",fields:[{key:"flows",label:"Cash Flows",type:"text",placeholder:"-50000000,12000000,15000000,18000000"}]},
{id:"profit",name:"Profit Method",description:"Capitalise the maintainable divisible balance.",category:"Specialised Valuation",fields:[money("receipts","Gross Receipts"),money("expenses","Working Expenses"),money("share","Relevant Share"),rate()]},
{id:"yield",name:"Yield / Capitalisation Rate",description:"Calculate yield from net income and capital value.",category:"Investment Analysis",fields:[money("income","Net Annual Income"),money("value","Capital Value")]},
{id:"ltv",name:"Loan-to-Value",description:"Calculate loan-to-value and equity.",category:"Finance",fields:[money("value","Property Value"),money("loan","Loan Amount")]},
{id:"marriage",name:"Marriage Value",description:"Calculate additional value created by combining interests.",category:"Specialised Valuation",fields:[money("a","Interest A"),money("b","Interest B"),money("combined","Combined Value")]},
{id:"compensation",name:"Compensation",description:"Educational breakdown of common compensation components.",category:"Statutory",fields:[money("land","Land / Interest Value"),money("disturbance","Disturbance"),money("severance","Severance"),money("injurious","Injurious Affection"),money("other","Other Allowable Amounts")]}
];

export const formulas = [
["Y.P. in Perpetuity","Y.P. = 1 / r","Used when income continues indefinitely."],
["Y.P. Term Certain","Y.P. = [1 − (1+r)^−n] / r","Used for income over a fixed term."],
["Present Value","PV = FV / (1+r)^n","Discounts a future amount to today's value."],
["Investment Method","Value = Net Income / Yield","Used for income-producing property."],
["Term & Reversion","Value = Term + Reversion","Separates current income from future market rent."],
["Comparison Method","Rate = Sale Price / Unit","Uses comparable market transactions."],
["Cost Method","Value = Land + Depreciated Building","Useful where direct market evidence is limited."],
["Residual Method","Residual = GDV − Costs − Profit","Used in development appraisal."],
["DCF","PV = CF / (1+r)^n","Discounts each future cash flow."],
["NPV","NPV = Σ PV of Cash Flows − Initial Investment","Measures value added at a discount rate."],
["IRR","Rate where NPV = 0","Internal return implied by a cash-flow series."],
["Yield","Yield = Net Income / Capital Value × 100","Converts income and value into a rate."],
["LTV","LTV = Loan / Property Value × 100","Measures leverage."],
["Marriage Value","Combined Value − (A + B)","Additional value from combining interests."]
] as const;

export const categories = [...new Set(calculators.map(c=>c.category))];